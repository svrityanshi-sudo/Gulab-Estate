GULAB ESTATE WEBSITE — UPDATE INSTRUCTIONS

Files
- index.html: complete responsive website. No separate CSS or JavaScript files are required; both are included in this file.

Upload / update on GitHub
1. Open https://github.com/svrityanshi-sudo/Gulab-Estate
2. Open the repository's main page and tap Add file > Upload files.
3. Select the updated index.html from this package.
4. If GitHub says index.html already exists, make sure you are replacing the existing file, not uploading it into a folder.
5. Scroll down, enter a commit message such as "Upgrade Gulab Estate luxury design", and tap Commit changes.
6. Open Settings > Pages. Under Build and deployment, select Deploy from a branch, choose main and /(root), then Save if not already configured.
7. After deployment, visit https://svrityanshi-sudo.github.io/Gulab-Estate/

Important before sharing with customers
- The project images are illustrative stock photos, not verified photos of these specific plots. Replace them with genuine project photos when available.
- Confirm current rates, plot availability, dimensions, distances, ownership/title, approvals and other legal details before publishing or accepting bookings.
- The contact form opens the visitor's email app; it does not store submissions. The floating WhatsApp button opens a WhatsApp chat with the configured number.
